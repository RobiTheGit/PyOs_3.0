#!/usr/bin/python3
import webbrowser
webbrowser.open("https://google.com")
